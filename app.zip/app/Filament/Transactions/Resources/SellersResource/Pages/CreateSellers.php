<?php

namespace App\Filament\Transactions\Resources\SellersResource\Pages;

use App\Filament\Transactions\Resources\SellersResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSellers extends CreateRecord
{
    protected static string $resource = SellersResource::class;
}

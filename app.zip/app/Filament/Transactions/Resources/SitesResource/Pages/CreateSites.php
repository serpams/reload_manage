<?php

namespace App\Filament\Transactions\Resources\SitesResource\Pages;

use App\Filament\Transactions\Resources\SitesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSites extends CreateRecord
{
    protected static string $resource = SitesResource::class;
}

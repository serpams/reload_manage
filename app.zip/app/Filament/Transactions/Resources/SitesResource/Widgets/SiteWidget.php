<?php

namespace App\Filament\Transactions\Resources\SitesResource\Widgets;

use Filament\Widgets\Widget;

class SiteWidget extends Widget
{


    protected static string $view = 'filament.transactions.resources.sites-resource.widgets.site-widget';

}

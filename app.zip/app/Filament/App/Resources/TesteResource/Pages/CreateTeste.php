<?php

namespace App\Filament\App\Resources\TesteResource\Pages;

use App\Filament\App\Resources\TesteResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTeste extends CreateRecord
{
    protected static string $resource = TesteResource::class;
}
